-- Stops the background keyword check when Lightroom quits or the plugin is reloaded.
pcall(function() require("ADClient").running = false end)
