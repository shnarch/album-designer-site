--[[ Talking to the FlowAlbum app (a local web server, by default http://127.0.0.1:8787). ]]

local LrApplication = import "LrApplication"
local LrFileUtils = import "LrFileUtils"
local LrHttp = import "LrHttp"
local LrStringUtils = import "LrStringUtils"

local AD = {}

AD.DEFAULT_SERVER = "http://127.0.0.1:8787"
AD.DEFAULT_COLLECTION = "Not in a story"

function AD.base(settings)
  local s = (settings and settings.ad_server) or AD.DEFAULT_SERVER
  if s == "" then s = AD.DEFAULT_SERVER end
  return (s:gsub("/+$", ""))
end

-- The project a service sends to: its Project setting, else the service's name (its Description in
-- the Publish Manager); blank only when neither is known (the app then uses the last-edited project).
-- `service`: the LrPublishService, when the caller has it; without one, the plugin's only service.
function AD.project(settings, service)
  local p = settings and settings.ad_project
  if p and p ~= "" then return p end
  p = settings and settings.LR_publish_connectionName
  if p and p ~= "" then return p end
  if not service then
    pcall(function()
      local services = LrApplication.activeCatalog():getPublishServices(_PLUGIN.id) or {}
      if #services == 1 then service = services[1] end
    end)
  end
  if service then
    local ok, name = pcall(function() return service:getName() end)
    if ok and name and name ~= "" then return name end
  end
  return ""
end

-- Plain settings with the project resolved, for calls made away from the dialog
function AD.target(settings, service)
  return { ad_server = settings.ad_server, ad_project = AD.project(settings, service) }
end

function AD.urlencode(s)
  return (tostring(s or ""):gsub("[^%w%-%._~]", function(c) return string.format("%%%02X", string.byte(c)) end))
end

local ESCAPES = { ['"'] = '\\"', ["\\"] = "\\\\", ["\n"] = "\\n", ["\r"] = "\\r", ["\t"] = "\\t" }
local function jsonString(s)
  return '"' .. tostring(s):gsub('[%c"\\]', function(c)
    return ESCAPES[c] or string.format("\\u%04x", string.byte(c))
  end) .. '"'
end

-- JSON for flat tables of strings / numbers / booleans, and arrays of strings
function AD.json(t)
  if #t > 0 then
    local items = {}
    for _, v in ipairs(t) do items[#items + 1] = jsonString(v) end
    return "[" .. table.concat(items, ",") .. "]"
  end
  local parts = {}
  for k, v in pairs(t) do
    local tv, val = type(v), nil
    if tv == "string" then val = jsonString(v)
    elseif tv == "number" then val = tostring(v)
    elseif tv == "boolean" then val = v and "true" or "false"
    elseif tv == "table" then val = AD.json(v) end
    if val then parts[#parts + 1] = jsonString(k) .. ":" .. val end
  end
  return "{" .. table.concat(parts, ",") .. "}"
end

local function field(json, key)
  return json and json:match('"' .. key .. '"%s*:%s*"([^"]*)"')
end

local function notRunning(settings, hdrs)
  if hdrs and hdrs.status then
    return string.format("FlowAlbum answered with an error (HTTP %s).", tostring(hdrs.status))
  end
  return "Couldn't reach FlowAlbum at " .. AD.base(settings) ..
    ". Start FlowAlbum (open it from your Start menu or Applications folder, or double-click “FlowAlbum.command”) and try again."
end

-- What we tell the app about a photo (read while publishing; runs inside an async task)
function AD.photoMeta(photo)
  return {
    uuid = photo:getRawMetadata("uuid"),
    file_name = photo:getFormattedMetadata("fileName") or "",
    rating = photo:getRawMetadata("rating") or 0,
    pick = photo:getRawMetadata("pickStatus") or 0,
    label = photo:getRawMetadata("colorNameForLabel") or "",
    keywords = photo:getFormattedMetadata("keywordTags") or "",
    title = photo:getFormattedMetadata("title") or "",
    caption = photo:getFormattedMetadata("caption") or "",
  }
end

-- Send one rendered JPEG. Returns a result table, or nil and an error message.
function AD.publish(settings, path, meta)
  local body = LrFileUtils.readFile(path)
  if not body then return nil, "Couldn't read the rendered photo." end
  local url = AD.base(settings) .. "/api/lr/publish?project=" .. AD.urlencode(AD.project(settings))
  local headers = {
    { field = "Content-Type", value = "image/jpeg" },
    { field = "X-AD-Meta", value = LrStringUtils.encodeBase64(AD.json(meta)) },
  }
  local result, hdrs = LrHttp.post(url, body, headers, "POST", 180)
  if not result or not hdrs or hdrs.status ~= 200 then return nil, notRunning(settings, hdrs) end
  return {
    photo_id = field(result, "photo_id"),
    status = field(result, "status"),
    story_id = field(result, "story_id"),
    view_url = field(result, "view_url"),
  }
end

function AD.unpublish(settings, uuids)
  local body = '{"project":' .. jsonString(AD.project(settings)) .. ',"uuids":' .. AD.json(uuids) .. "}"
  local result, hdrs = LrHttp.post(AD.base(settings) .. "/api/lr/unpublish", body,
    { { field = "Content-Type", value = "application/json" } }, "POST", 60)
  if not result or not hdrs or hdrs.status ~= 200 then return nil, notRunning(settings, hdrs) end
  return true
end

function AD.renameStory(settings, storyId, name)
  local body = AD.json({ project = AD.project(settings), story_id = storyId, name = name })
  local result, hdrs = LrHttp.post(AD.base(settings) .. "/api/lr/rename", body,
    { { field = "Content-Type", value = "application/json" } }, "POST", 30)
  return result and hdrs and hdrs.status == 200
end

-- Which project the app will use, and that it is running
function AD.ping(settings)
  local result, hdrs = LrHttp.get(AD.base(settings) .. "/api/lr/status?project=" .. AD.urlencode(AD.project(settings)), nil, 15)
  if not result or not hdrs or hdrs.status ~= 200 then return nil, notRunning(settings, hdrs) end
  return field(result, "project")
end

-- Keyword "in album - <project name>" on published photos that are on album pages; removed from
-- the project's other published photos. Returns the number of photos in the album and the keyword,
-- or nil and an error message.
-- `known`: the app's previous answer; when nothing changed, the catalog isn't touched (returns
-- false). `peek`: never create a project (the background check).
function AD.markInAlbum(settings, known, peek)
  local result, hdrs = LrHttp.get(AD.base(settings) .. "/api/lr/status?project=" .. AD.urlencode(AD.project(settings)) ..
    (peek and "&peek=1" or ""), nil, 20)
  if not result or not hdrs or hdrs.status ~= 200 then return nil, notRunning(settings, hdrs) end
  if known and known == result then return false, nil, result end
  local inAlbum = {}
  for u in (result:match('"in_album"%s*:%s*%[(.-)%]') or ""):gmatch('"([^"]+)"') do inAlbum[u] = true end
  local all = {}
  for u in (result:match('"all"%s*:%s*%[(.-)%]') or ""):gmatch('"([^"]+)"') do all[#all + 1] = u end
  local name = field(result, "name") or field(result, "project") or "album"
  local keywordName = "in album - " .. name
  local catalog = LrApplication.activeCatalog()
  local count = 0
  local status = catalog:withWriteAccessDo("FlowAlbum: mark photos in the album", function()
    local keyword = catalog:createKeyword(keywordName, {}, false, nil, true)
    for _, u in ipairs(all) do
      local photo = catalog:findPhotoByUuid(u)
      if photo then
        if inAlbum[u] then
          photo:addKeyword(keyword)
          count = count + 1
        else
          photo:removeKeyword(keyword)
        end
      end
    end
  end, { timeout = 60 })
  if status and status ~= "executed" then
    return nil, "Lightroom's catalog was busy (" .. tostring(status) .. ")."
  end
  return count, keywordName, result
end

-- Albums deleted in the app: remove their "in album - <name>" keyword from their photos.
-- Returns the number of albums cleaned up, or nil and an error message.
function AD.cleanDeletedAlbums(settings)
  local result, hdrs = LrHttp.get(AD.base(settings) .. "/api/lr/deleted", nil, 20)
  if not result or not hdrs or hdrs.status ~= 200 then return nil, notRunning(settings, hdrs) end
  local albums = {}
  for entry in result:gmatch('{[^{}]*}') do
    local uuids = {}
    for u in (entry:match('"uuids"%s*:%s*%[(.-)%]') or ""):gmatch('"([^"]+)"') do uuids[#uuids + 1] = u end
    local id, name = field(entry, "id"), field(entry, "name")
    if id and name then albums[#albums + 1] = { id = id, name = name, uuids = uuids } end
  end
  if #albums == 0 then return 0 end
  local catalog = LrApplication.activeCatalog()
  local status = catalog:withWriteAccessDo("FlowAlbum: remove keywords of deleted albums", function()
    for _, a in ipairs(albums) do
      local keyword = catalog:createKeyword("in album - " .. a.name, {}, false, nil, true)
      for _, u in ipairs(a.uuids) do
        local photo = catalog:findPhotoByUuid(u)
        if photo then photo:removeKeyword(keyword) end
      end
    end
  end, { timeout = 60 })
  if status and status ~= "executed" then return nil, "Lightroom's catalog was busy." end
  local ids = {}
  for _, a in ipairs(albums) do ids[#ids + 1] = a.id end
  LrHttp.post(AD.base(settings) .. "/api/lr/deleted-done", AD.json({ ids = ids }),
    { { field = "Content-Type", value = "application/json" } }, "POST", 20)
  return #albums
end

return AD
