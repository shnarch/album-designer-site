--[[ The "FlowAlbum" publish service.
Each published collection is a story in FlowAlbum. Publishing renders each photo at print
size and sends it, with its Lightroom metadata, to the running app. ]]

local LrDialogs = import "LrDialogs"
local LrLogger = import "LrLogger"
local LrFileUtils = import "LrFileUtils"
local LrTasks = import "LrTasks"
local LrView = import "LrView"

local AD = require "ADClient"

local log = LrLogger("AlbumDesigner")      -- ~/Documents/LrClassicLogs/AlbumDesigner.log
log:enable("logfile")

local provider = {}

-- publish only (no one-off export), JPEG for print
provider.supportsIncrementalPublish = "only"
provider.allowFileFormats = { "JPEG" }
provider.allowColorSpaces = { "sRGB", "AdobeRGB" }
provider.canExportVideo = false
-- File Settings and Image Sizing are yours to set; location, naming, sharpening and metadata
-- are handled by the plugin (see updateExportSettings)
provider.hideSections = { "exportLocation", "fileNaming", "outputSharpening", "metadata",
  "watermarking", "video", "postProcessing" }

-- defaults for File Settings and Image Sizing
local DEFAULTS = {
  LR_format = "JPEG",
  LR_jpeg_quality = 0.75,
  LR_jpeg_useLimitSize = false,
  LR_jpeg_limitSize = 2000,
  LR_export_colorSpace = "sRGB",
  LR_export_bitDepth = 8,
  LR_size_doConstrain = true,
  LR_size_resizeType = "longEdge",
  LR_size_maxWidth = 4000,
  LR_size_maxHeight = 4000,
  LR_size_units = "pixels",
  LR_size_doNotEnlarge = false,
  LR_size_resolution = 240,
  LR_size_resolutionUnits = "inch",
}

provider.exportPresetFields = {
  { key = "ad_server", default = AD.DEFAULT_SERVER },
  { key = "ad_project", default = "" },
  { key = "ad_markInAlbum", default = true },
  { key = "ad_stories", default = true },          -- each collection is a story in the app
  { key = "ad_defaultsApplied", default = false },
}

-- services set up before File Settings / Image Sizing were shown get the defaults once
function provider.startDialog(props)
  if not props.ad_defaultsApplied then
    for k, v in pairs(DEFAULTS) do props[k] = v end
    props.ad_defaultsApplied = true
  end
end

-- the parts you don't see: matte output sharpening and all metadata
function provider.updateExportSettings(s)
  s.LR_format = "JPEG"
  s.LR_outputSharpeningOn = true
  s.LR_outputSharpeningMedia = "matte"
  s.LR_outputSharpeningLevel = 2
  s.LR_embeddedMetadataOption = "all"
end

function provider.sectionsForTopOfDialog(f, props)
  local bind, share = LrView.bind, LrView.share
  return {
    {
      title = "FlowAlbum",
      synopsis = bind { key = "ad_project", transform = function(v)
        return (v and v ~= "") and ("Project: " .. v) or "Project: the service's Description"
      end },
      f:row {
        f:static_text { title = "Project:", alignment = "right", width = share "ad_lbl" },
        f:edit_field { value = bind "ad_project", width_in_chars = 26, immediate = true },
      },
      f:row {
        f:spacer { width = share "ad_lbl" },
        f:static_text { title = "The album's name in FlowAlbum. Empty: this service's Description (above).\nA name that doesn't exist yet creates a new project.",
          height_in_lines = 2, width_in_chars = 50, size = "small" },
      },
      f:row {
        f:static_text { title = "App address:", alignment = "right", width = share "ad_lbl" },
        f:edit_field { value = bind "ad_server", width_in_chars = 26 },
        f:push_button { title = "Test", action = function()
          LrTasks.startAsyncTask(function()
            local project, err = AD.ping(props)
            if project then
              LrDialogs.message("FlowAlbum is running", "Photos will go to the project “" .. project .. "”.", "info")
            else
              LrDialogs.message("FlowAlbum", err, "warning")
            end
          end)
        end },
      },
      f:row {
        f:spacer { width = share "ad_lbl" },
        f:checkbox { title = "After publishing, add the keyword “in album - <project name>” to photos on album pages",
          value = bind "ad_markInAlbum" },
      },
      f:row {
        f:spacer { width = share "ad_lbl" },
        f:checkbox { title = "Each collection is a story in FlowAlbum",
          value = bind "ad_stories" },
      },
      f:row {
        f:spacer { width = share "ad_lbl" },
        f:static_text { title = "Uncheck to send photos without a story and split them into stories in the app\n(the Photos tab). Photos in “Not in a story” never get a story.",
          height_in_lines = 2, width_in_chars = 50, size = "small" },
      },
    },
  }
end

-- collections = stories
function provider.getCollectionBehaviorInfo(publishSettings)
  return {
    defaultCollectionName = AD.DEFAULT_COLLECTION,
    defaultCollectionCanBeDeleted = false,
    canAddCollection = true,
    maxCollectionSetDepth = 0,
  }
end
provider.titleForPublishedCollection = "Story"
provider.titleForPublishedCollection_standalone = "Story"
provider.titleForGoToPublishedCollection = "Open FlowAlbum"
provider.titleForGoToPublishedPhoto = "Open FlowAlbum"
provider.supportsCustomSortOrder = false

-- re-edits always republish; of the metadata, only what the app uses
function provider.metadataThatTriggersRepublish(publishSettings)
  return { default = false, title = true, caption = true, keywords = false, rating = true, label = true, dateCreated = true }
end

function provider.processRenderedPhotos(functionContext, exportContext)
  local session = exportContext.exportSession
  local settings = exportContext.propertyTable
  local target = AD.target(settings, exportContext.publishService)
  local info = exportContext.publishedCollectionInfo or {}
  local collection = info.name or ""
  local isDefault = info.isDefaultCollection or collection == AD.DEFAULT_COLLECTION
  local collectionId = info.remoteId
  local n = session:countRenditions()
  local progress = exportContext:configureProgress {
    title = n == 1 and "Sending a photo to FlowAlbum" or string.format("Sending %d photos to FlowAlbum", n),
  }
  local sent = 0
  for _, rendition in exportContext:renditions { stopIfCanceled = true } do
    local ok, pathOrMessage = rendition:waitForRender()
    if progress:isCanceled() then break end
    if ok then
      local meta = AD.photoMeta(rendition.photo)
      meta.collection = collection
      -- no story: the built-in collection, or the service sends everything without stories
      meta.default_collection = (isDefault or settings.ad_stories == false) and true or false
      meta.collection_id = collectionId
      local result, err = AD.publish(target, pathOrMessage, meta)
      LrFileUtils.delete(pathOrMessage)
      if result then
        rendition:recordPublishedPhotoId(meta.uuid)
        rendition:recordPublishedPhotoUrl(result.view_url or AD.base(settings))
        if result.story_id and not collectionId and not meta.default_collection then
          pcall(function()
            session:recordRemoteCollectionId(result.story_id)
            session:recordRemoteCollectionUrl(result.view_url or AD.base(settings))
          end)
          collectionId = result.story_id
        end
        sent = sent + 1
      else
        rendition:uploadFailed(err)
      end
    else
      rendition:uploadFailed(pathOrMessage)
    end
  end
  if sent > 0 and settings.ad_markInAlbum then
    -- after the publish has finished (the catalog is busy until then). Plain values only: the
    -- export settings may be gone by the time this runs.
    LrTasks.startAsyncTask(function()
      local count, keyword, err
      for attempt = 1, 6 do
        LrTasks.sleep(attempt == 1 and 2 or 5)
        -- LrTasks.pcall, not pcall: the HTTP call and catalog write yield, which plain pcall can't
        local ok, a, b = LrTasks.pcall(AD.markInAlbum, target, nil, false)
        if ok and a then count, keyword = a, b break end
        err = ok and b or a
        log:warn("Marking photos in the album, attempt " .. attempt .. ": " .. tostring(err))
      end
      if count then
        LrDialogs.showBezel(string.format("%d photo%s tagged “%s”", count, count == 1 and "" or "s", keyword))
      else
        LrDialogs.message("FlowAlbum", "The photos were published, but tagging them “in album” failed:\n" .. tostring(err) ..
          "\n\nTry Library › Plug-in Extras › Mark photos in the album.", "warning")
      end
    end)
  end
end

-- removed from a collection (and published): out of the album, kept in the app's library
function provider.deletePhotosFromPublishedCollection(publishSettings, arrayOfPhotoIds, deletedCallback)
  local ok, err = AD.unpublish(publishSettings, arrayOfPhotoIds)
  if not ok then error(err) end
  for _, id in ipairs(arrayOfPhotoIds) do deletedCallback(id) end
end

-- renaming a collection renames its story
function provider.renamePublishedCollection(publishSettings, info)
  if info.remoteId then AD.renameStory(publishSettings, info.remoteId, info.name) end
end

return provider
