--[[ FlowAlbum — Lightroom Classic plugin.
Adds an "FlowAlbum" publish service: each collection under it is a story in the app,
and Publish sends print-size renderings (plus rating, flag, label, keywords) to the running app. ]]

return {
  LrSdkVersion = 10.0,
  LrSdkMinimumVersion = 6.0,
  LrToolkitIdentifier = "com.albumdesigner.lightroom",
  LrPluginName = "FlowAlbum",
  LrPluginInfoUrl = "http://127.0.0.1:8787/",
  LrInitPlugin = "Init.lua",
  LrShutdownPlugin = "Shutdown.lua",

  LrExportServiceProvider = {
    title = "FlowAlbum",
    file = "AlbumDesignerPublish.lua",
  },

  LrLibraryMenuItems = {
    { title = "Mark photos in the album", file = "MarkInAlbum.lua" },
  },

  VERSION = { major = 1, minor = 1, revision = 0, build = 2 },
}
