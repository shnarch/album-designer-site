--[[ While Lightroom is open, keep the "in album - <project name>" keyword in step with the app:
every 30 seconds (only while FlowAlbum is running), photos that joined or left an album, photos
deleted in the app, and albums deleted in the app are updated. The catalog is only written when
something changed. Nothing here may stop the plugin from loading: every step is guarded. ]]

local LrTasks = import "LrTasks"

LrTasks.startAsyncTask(function()
  LrTasks.pcall(function()
    local LrApplication = import "LrApplication"
    local LrLogger = import "LrLogger"
    local AD = require "ADClient"
    local log = LrLogger("AlbumDesigner")
    log:enable("logfile")
    log:info("Background keyword check started")
    AD.running = true
    local seen = {}          -- the app's last answer per publish service
    LrTasks.sleep(15)        -- let Lightroom finish starting
    while AD.running do
      local ok, err = LrTasks.pcall(function()
        local services = LrApplication.activeCatalog():getPublishServices(_PLUGIN.id) or {}
        for i, service in ipairs(services) do
          local settings = service:getPublishSettings()
          if settings and settings.ad_markInAlbum ~= false then
            local n, _, answer = AD.markInAlbum(AD.target(settings, service), seen[i], true)
            if n ~= nil and answer then seen[i] = answer end
          end
        end
        if services[1] then AD.cleanDeletedAlbums(services[1]:getPublishSettings()) end
      end)
      if not ok then log:info("Background keyword check: " .. tostring(err)) end
      for _ = 1, 30 do
        if not AD.running then break end
        LrTasks.sleep(1)
      end
    end
  end)
end)
