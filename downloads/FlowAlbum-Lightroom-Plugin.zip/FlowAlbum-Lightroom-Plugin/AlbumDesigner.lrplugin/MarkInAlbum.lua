--[[ Library › Plug-in Extras › Mark photos in the album
Adds the keyword "in album - <project name>" to photos that are on album pages, and removes it from
published photos that are not (any more). ]]

local LrApplication = import "LrApplication"
local LrDialogs = import "LrDialogs"
local LrTasks = import "LrTasks"

local AD = require "ADClient"

LrTasks.startAsyncTask(function()
  local catalog = LrApplication.activeCatalog()
  local services = catalog:getPublishServices(_PLUGIN.id)
  if not services or #services == 0 then
    LrDialogs.message("FlowAlbum", "Set up the FlowAlbum publish service first (Publish Services panel › Set Up…).", "info")
    return
  end
  local lines = {}
  for _, service in ipairs(services) do
    local n, keyword = AD.markInAlbum(AD.target(service:getPublishSettings(), service))
    if not n then
      LrDialogs.message("FlowAlbum", keyword, "warning")
      return
    end
    lines[#lines + 1] = string.format("%d photo%s tagged “%s”", n, n == 1 and "" or "s", keyword)
  end
  local cleaned = AD.cleanDeletedAlbums(services[1]:getPublishSettings())
  if cleaned and cleaned > 0 then
    lines[#lines + 1] = string.format("keywords removed for %d deleted album%s", cleaned, cleaned == 1 and "" or "s")
  end
  LrDialogs.showBezel(table.concat(lines, " · "))
end)
